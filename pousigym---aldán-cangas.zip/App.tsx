
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Schedule from './components/Schedule';
import Trainers from './components/Trainers';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AISuggestion from './components/AISuggestion';
import { ChevronLeft } from 'lucide-react';

const PageHero: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => {
  const handleBack = (e: React.MouseEvent) => {
    e.preventDefault();
    const url = new URL(window.location.href);
    url.searchParams.delete('view');
    window.history.pushState({}, '', url.toString());
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  return (
    <section className="relative pt-48 pb-24 bg-secondary overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[150px]"></div>
      </div>
      <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
        <a 
          href="?"
          onClick={handleBack}
          className="mb-8 inline-flex items-center gap-2 text-zinc-500 hover:text-primary transition-colors text-xs font-black uppercase tracking-widest group cursor-pointer"
        >
          <ChevronLeft size={16} className="transition-transform group-hover:-translate-x-1" /> Volver al Inicio
        </a>
        <h1 className="font-display text-7xl md:text-9xl font-black uppercase tracking-tighter leading-[0.85] mb-6">
          {title.split(' ').map((word, i) => (
            <span key={i} className={i % 2 !== 0 ? 'text-primary' : 'text-white'}>
              {word}{' '}
            </span>
          ))}
        </h1>
        <p className="text-zinc-500 uppercase tracking-[0.4em] font-bold text-sm md:text-base">
          {subtitle}
        </p>
      </div>
    </section>
  );
};

const App: React.FC = () => {
  const [view, setView] = useState<string>('full');

  useEffect(() => {
    const handleUrlChange = () => {
      const params = new URLSearchParams(window.location.search);
      const viewParam = params.get('view');
      setView(viewParam || 'full');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  const renderContent = () => {
    switch (view) {
      case 'inicio':
        return <Hero />;
      case 'sobre-nosotros':
        return (
          <>
            <PageHero title="SOBRE NOSOTROS" subtitle="La historia y valores de PousiGym Aldán" />
            <About />
            <Testimonials />
          </>
        );
      case 'servicios':
        return (
          <>
            <PageHero title="NUESTROS SERVICIOS" subtitle="Excelencia técnica en cada entrenamiento" />
            <Services />
            <AISuggestion />
          </>
        );
      case 'horarios':
        return (
          <>
            <PageHero title="HORARIOS CLASES" subtitle="Organiza tu semana con nuestros expertos" />
            <Schedule />
          </>
        );
      case 'entrenadores':
        return (
          <>
            <PageHero title="STAFF TÉCNICO" subtitle="Liderazgo y pasión por el fitness" />
            <Trainers />
          </>
        );
      case 'tarifas':
        return (
          <>
            <PageHero title="PLANES Y PRECIOS" subtitle="Invierte en tu mejor versión hoy mismo" />
            <Pricing />
          </>
        );
      case 'contacto':
        return (
          <>
            <PageHero title="CONTACTA CON NOSOTROS" subtitle="Estamos en Cangas para ayudarte" />
            <Contact />
          </>
        );
      default:
        return (
          <>
            <Hero />
            <About />
            <Services />
            <Schedule />
            <Trainers />
            <Pricing />
            <Testimonials />
            <AISuggestion />
            <Contact />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-secondary text-slate-50">
      <Header currentView={view} />
      <main className="flex-grow">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default App;
