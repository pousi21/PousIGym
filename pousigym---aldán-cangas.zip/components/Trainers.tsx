
import React from 'react';
import { Instagram, Linkedin, Twitter, Award } from 'lucide-react';

const Trainers: React.FC = () => {
  const trainers = [
    {
      name: 'David Pousada Rial',
      role: 'Director y Head Coach',
      specialty: 'Powerlifting & Bodybuilding',
      bio: 'Arquitecto de físicos y mente. David combina años de experiencia competitiva con una visión técnica impecable.',
      image: 'https://images.unsplash.com/photo-1594381898411-846e7d193883?q=80&w=1000&auto=format&fit=crop'
    },
    {
      name: 'Ana Belén Martínez',
      role: 'Especialista en HIIT',
      specialty: 'Acondicionamiento Físico',
      bio: 'Energía inagotable. Ana transformará tu resistencia y quemará tus límites en cada sesión dirigida.',
      image: 'https://images.unsplash.com/photo-1548690312-e3b507d17a12?q=80&w=1000&auto=format&fit=crop'
    },
    {
      name: 'Carlos Otero',
      role: 'Coach de Movilidad',
      specialty: 'Rehabilitación & Yoga',
      bio: 'El equilibrio necesario. Carlos asegura que tu cuerpo sea tan móvil y elástico como fuerte.',
      image: 'https://images.unsplash.com/photo-1567013127542-490d757e51fe?q=80&w=1000&auto=format&fit=crop'
    }
  ];

  return (
    <section id="entrenadores" className="py-32 bg-secondary relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 p-20 opacity-[0.02] select-none pointer-events-none">
        <h2 className="text-[20rem] font-display font-black leading-none">TRAINERS</h2>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-20 gap-8">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 text-primary font-black uppercase tracking-[0.3em] text-xs">
              <Award size={16} /> Staff de Élite
            </div>
            <h3 className="text-5xl md:text-6xl font-display font-black uppercase tracking-tighter">
              GUIADO POR <span className="text-primary">LOS MEJORES</span>
            </h3>
          </div>
          <p className="text-zinc-500 max-w-md text-lg font-medium border-l-2 border-primary pl-6">
            Profesionales titulados, apasionados y comprometidos con cada uno de tus objetivos.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10 lg:gap-16">
          {trainers.map((trainer, index) => (
            <div key={index} className="group flex flex-col space-y-8">
              <div className="relative w-full aspect-[3/4] overflow-hidden rounded-[2.5rem] bg-zinc-800 ring-1 ring-white/10 group-hover:ring-primary/50 transition-all duration-500">
                <img 
                  src={trainer.image} 
                  alt={trainer.name} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-100 group-hover:scale-105" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary via-transparent to-transparent opacity-80 group-hover:opacity-40 transition-opacity"></div>
                
                {/* Social Floating */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 opacity-0 translate-y-6 transition-all duration-500 group-hover:opacity-100 group-hover:translate-y-0">
                  <a href="#" className="bg-primary p-3 rounded-2xl text-secondary hover:bg-white transition-all shadow-xl"><Instagram size={20} /></a>
                  <a href="#" className="bg-primary p-3 rounded-2xl text-secondary hover:bg-white transition-all shadow-xl"><Linkedin size={20} /></a>
                </div>
              </div>
              
              <div className="space-y-4 px-2">
                <div>
                  <h4 className="text-3xl font-display font-black uppercase tracking-tight text-white group-hover:text-primary transition-colors">
                    {trainer.name}
                  </h4>
                  <p className="text-primary font-black text-xs uppercase tracking-[0.25em] mt-1">{trainer.role}</p>
                </div>
                <p className="text-zinc-500 text-sm italic font-bold leading-none bg-white/5 py-1 px-2 rounded inline-block">{trainer.specialty}</p>
                <p className="text-zinc-400 leading-relaxed font-medium">
                  {trainer.bio}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Trainers;
