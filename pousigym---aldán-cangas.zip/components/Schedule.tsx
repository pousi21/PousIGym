
import React from 'react';

const Schedule: React.FC = () => {
  const scheduleData = [
    { time: '08:00 - 09:00', mon: 'HIIT', tue: 'Spinning', wed: 'HIIT', thu: 'Cross Training', fri: 'Yoga', sat: 'Open Gym' },
    { time: '09:30 - 10:30', mon: 'Yoga', tue: 'Musculación', wed: 'Spinning', thu: 'HIIT', fri: 'Cross Training', sat: 'HIIT' },
    { time: '11:00 - 12:00', mon: 'Cross Training', tue: 'HIIT', wed: 'Yoga', thu: 'Musculación', fri: 'Spinning', sat: 'Open Gym' },
    { time: '18:00 - 19:00', mon: 'HIIT', tue: 'Spinning', wed: 'Cross Training', thu: 'Yoga', fri: 'HIIT', sat: '-' },
    { time: '19:30 - 20:30', mon: 'Spinning', tue: 'HIIT', wed: 'Spinning', thu: 'Cross Training', fri: 'Open Gym', sat: '-' },
    { time: '20:30 - 21:30', mon: 'Musculación', tue: 'Cross Training', wed: 'Musculación', thu: 'Spinning', fri: 'Spinning', sat: '-' },
  ];

  return (
    <section id="horarios" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm">Horarios y Clases</h2>
          <h3 className="text-4xl md:text-5xl font-display font-black uppercase">PLANIFICA TU <span className="text-primary">SEMANA</span></h3>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-white/10 bg-zinc-900/50">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-primary/10">
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Horario</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Lunes</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Martes</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Miércoles</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Jueves</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Viernes</th>
                <th className="px-6 py-5 font-display text-primary uppercase tracking-widest text-sm border-b border-white/10">Sábado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {scheduleData.map((row, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-5 font-bold text-zinc-300">{row.time}</td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.mon !== '-' ? 'bg-zinc-800 text-zinc-300' : 'text-zinc-700'}`}>{row.mon}</span></td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.tue !== '-' ? 'bg-primary/20 text-primary' : 'text-zinc-700'}`}>{row.tue}</span></td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.wed !== '-' ? 'bg-zinc-800 text-zinc-300' : 'text-zinc-700'}`}>{row.wed}</span></td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.thu !== '-' ? 'bg-primary/20 text-primary' : 'text-zinc-700'}`}>{row.thu}</span></td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.fri !== '-' ? 'bg-zinc-800 text-zinc-300' : 'text-zinc-700'}`}>{row.fri}</span></td>
                  <td className="px-6 py-5"><span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${row.sat !== '-' ? 'bg-zinc-800 text-primary' : 'text-zinc-700'}`}>{row.sat}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-8 flex flex-wrap gap-4 justify-center text-xs uppercase tracking-widest font-bold text-zinc-500">
          <div className="flex items-center gap-2"><div className="w-3 h-3 bg-primary rounded-full"></div> Clases de Intensidad Alta</div>
          <div className="flex items-center gap-2"><div className="w-3 h-3 bg-zinc-800 rounded-full"></div> Clases Técnicas / Bienestar</div>
          <div className="flex items-center gap-2"><div className="w-3 h-3 bg-zinc-600 rounded-full"></div> Acceso Libre</div>
        </div>
      </div>
    </section>
  );
};

export default Schedule;
