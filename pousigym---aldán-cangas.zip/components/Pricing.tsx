
import React from 'react';
import { Check, ArrowRight } from 'lucide-react';

const Pricing: React.FC = () => {
  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', view);
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string) => {
    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  const plans = [
    {
      name: 'Plan Básico',
      price: '34.90€',
      description: 'Ideal para quienes entrenan a su aire.',
      features: ['Acceso ilimitado a sala', 'App de entrenamiento', 'Duchas y vestuarios', 'Seguimiento inicial'],
      isPopular: false
    },
    {
      name: 'Plan Estándar',
      price: '44.90€',
      description: 'Nuestra opción más equilibrada.',
      features: ['Todo lo del plan básico', 'Clases dirigidas ilimitadas', 'Acceso a la App Premium', '1 Análisis corporal / mes'],
      isPopular: true
    },
    {
      name: 'Plan Premium',
      price: '89.90€',
      description: 'Resultados acelerados al máximo.',
      features: ['Todo lo del plan estándar', '1 Sesión PT personal al mes', 'Plan nutricional personalizado', 'Acceso prioritario a talleres'],
      isPopular: false
    }
  ];

  return (
    <section id="tarifas" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm">Planes de Membresía</h2>
          <h3 className="text-4xl md:text-5xl font-display font-black uppercase">ELIGE TU <span className="text-primary">CAMINO</span></h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative p-10 rounded-3xl border transition-all duration-500 hover:translate-y-[-10px] ${
                plan.isPopular 
                ? 'bg-zinc-900 border-primary shadow-2xl shadow-primary/10' 
                : 'bg-secondary border-white/5 hover:border-primary/50'
              }`}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-secondary text-xs font-black uppercase px-4 py-1 rounded-full">
                  Más Popular
                </div>
              )}
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-2xl font-display font-bold uppercase">{plan.name}</h4>
                  <p className="text-zinc-500 text-sm mt-1">{plan.description}</p>
                </div>
                
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-display font-black text-white">{plan.price.split('€')[0]}</span>
                  <span className="text-xl font-display font-bold text-zinc-500">€/mes</span>
                </div>
                
                <ul className="space-y-4 py-6 border-y border-white/5">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-zinc-300 text-sm">
                      <div className="bg-primary/20 p-1 rounded-full">
                        <Check size={14} className="text-primary" />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <a 
                  href={getUrl('contacto')}
                  onClick={(e) => handleNavClick(e, 'contacto')}
                  className={`flex items-center justify-center gap-2 w-full py-4 rounded-xl font-bold uppercase tracking-widest transition-all ${
                    plan.isPopular 
                    ? 'bg-primary text-secondary hover:bg-accent' 
                    : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
                  }`}
                >
                  Elegir plan <ArrowRight size={18} />
                </a>
              </div>
            </div>
          ))}
        </div>
        
        <p className="text-center text-zinc-600 mt-12 text-sm italic">
          * Sin permanencia. Matrícula de 20€ para nuevos socios. IVA incluido.
        </p>
      </div>
    </section>
  );
};

export default Pricing;
