
import React from 'react';
import { Dumbbell, Instagram, Facebook, Twitter, Youtube, ArrowUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      if (view === 'inicio') {
        url.searchParams.delete('view');
      } else {
        url.searchParams.set('view', view);
      }
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string) => {
    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-secondary border-t border-white/5 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2 space-y-8">
            <div className="flex items-center gap-2">
              <Dumbbell className="text-primary w-10 h-10" />
              <span className="font-display text-3xl font-bold tracking-tighter italic">
                POUSI<span className="text-primary">GYM</span>
              </span>
            </div>
            <p className="text-zinc-500 max-w-sm text-lg leading-relaxed">
              Transformando el fitness en Aldán desde la base: técnica, salud y comunidad. Dirigido por David Pousada Rial.
            </p>
            <div className="flex gap-4">
              <a href="#" className="bg-white/5 p-3 rounded-full hover:bg-primary hover:text-secondary transition-all"><Instagram size={20} /></a>
              <a href="#" className="bg-white/5 p-3 rounded-full hover:bg-primary hover:text-secondary transition-all"><Facebook size={20} /></a>
              <a href="#" className="bg-white/5 p-3 rounded-full hover:bg-primary hover:text-secondary transition-all"><Twitter size={20} /></a>
              <a href="#" className="bg-white/5 p-3 rounded-full hover:bg-primary hover:text-secondary transition-all"><Youtube size={20} /></a>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="font-display text-xl font-bold uppercase tracking-widest text-white">Enlaces</h4>
            <ul className="space-y-4 text-zinc-500 font-semibold uppercase text-xs tracking-widest">
              <li><a href={getUrl('inicio')} onClick={(e) => handleNavClick(e, 'inicio')} className="hover:text-primary transition-colors">Inicio</a></li>
              <li><a href={getUrl('servicios')} onClick={(e) => handleNavClick(e, 'servicios')} className="hover:text-primary transition-colors">Servicios</a></li>
              <li><a href={getUrl('horarios')} onClick={(e) => handleNavClick(e, 'horarios')} className="hover:text-primary transition-colors">Horarios</a></li>
              <li><a href={getUrl('tarifas')} onClick={(e) => handleNavClick(e, 'tarifas')} className="hover:text-primary transition-colors">Membresía</a></li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="font-display text-xl font-bold uppercase tracking-widest text-white">Newsletter</h4>
            <p className="text-zinc-500 text-sm">Suscríbete para recibir consejos de entrenamiento y noticias de PousiGym.</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Email" className="bg-zinc-900 border border-white/5 rounded-lg px-4 py-2 text-sm w-full focus:outline-none focus:border-primary text-white" />
              <button className="bg-primary text-secondary px-4 py-2 rounded-lg font-bold">OK</button>
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-zinc-600 text-sm">
            © {new Date().getFullYear()} PousiGym Aldán. Creado por David Pousada Rial. Todos los derechos reservados.
          </p>
          <div className="flex gap-8 text-zinc-600 text-xs font-bold uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Aviso Legal</a>
            <a href="#" className="hover:text-white transition-colors">Privacidad</a>
            <a href="#" className="hover:text-white transition-colors">Cookies</a>
          </div>
          <button 
            onClick={scrollToTop}
            className="bg-primary/10 text-primary p-3 rounded-full border border-primary/20 hover:bg-primary hover:text-secondary transition-all"
          >
            <ArrowUp size={20} />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
