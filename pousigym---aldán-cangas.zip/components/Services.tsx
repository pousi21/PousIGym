
import React from 'react';
import { Dumbbell, Activity, UserCheck, Apple, ArrowUpRight } from 'lucide-react';

const Services: React.FC = () => {
  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', view);
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string) => {
    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  const services = [
    {
      title: 'Musculación y Cardio',
      description: 'Maquinaria de última generación para fuerza, hipertrofia y acondicionamiento cardiovascular.',
      icon: <Dumbbell className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=2070&auto=format&fit=crop'
    },
    {
      title: 'Clases Dirigidas',
      description: 'HIIT, Cross Training, Yoga, Spinning y más. Energía grupal para motivarte al máximo.',
      icon: <Activity className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1518611012118-29fa75a28420?q=80&w=2070&auto=format&fit=crop'
    },
    {
      title: 'Entrenamiento Personal',
      description: 'Programas adaptados a tus objetivos específicos con seguimiento continuo por David Pousada.',
      icon: <UserCheck className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=2070&auto=format&fit=crop'
    },
    {
      title: 'Nutrición Deportiva',
      description: 'Asesoramiento experto para que tu alimentación sea el motor de tus resultados físicos.',
      icon: <Apple className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=2053&auto=format&fit=crop'
    }
  ];

  return (
    <section id="servicios" className="py-24 bg-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm">Nuestros Servicios</h2>
          <h3 className="text-4xl md:text-5xl font-display font-black uppercase">EQUIPAMIENTO DE <span className="text-primary">ELITE</span></h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <a 
              key={index} 
              href={getUrl('contacto')}
              onClick={(e) => handleNavClick(e, 'contacto')}
              className="group relative overflow-hidden rounded-2xl bg-zinc-950 border border-white/5 hover:border-primary/50 transition-all duration-500 block"
            >
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4 bg-primary text-secondary p-2 rounded-full translate-y-[-50px] opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <ArrowUpRight size={20} />
                </div>
              </div>
              <div className="p-8 space-y-4">
                <div className="bg-primary/10 text-primary p-3 rounded-lg w-fit group-hover:bg-primary group-hover:text-secondary transition-colors duration-500">
                  {service.icon}
                </div>
                <h4 className="text-xl font-bold uppercase tracking-tight group-hover:text-primary transition-colors">{service.title}</h4>
                <p className="text-zinc-500 text-sm leading-relaxed">{service.description}</p>
                <p className="text-xs font-black uppercase tracking-widest text-primary pt-2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  Saber más <ArrowUpRight size={14} />
                </p>
              </div>
              <div className="absolute inset-x-0 bottom-0 h-1 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
