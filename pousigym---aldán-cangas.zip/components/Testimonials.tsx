
import React from 'react';
import { Quote, Star } from 'lucide-react';

const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: 'Marcos R.',
      text: 'El ambiente en PousiGym es increíble. David me ha ayudado a superar lesiones que arrastraba años con su técnica de entrenamiento.',
      rating: 5,
      image: 'https://i.pravatar.cc/150?u=marcos'
    },
    {
      name: 'Lucía S.',
      text: 'Buscaba un gimnasio en Aldán que no fuera solo máquinas. Las clases dirigidas son brutales y el equipo es súper amable.',
      rating: 5,
      image: 'https://i.pravatar.cc/150?u=lucia'
    },
    {
      name: 'Juan P.',
      text: 'Lo mejor de Cangas. Si quieres resultados reales y aprender a entrenar de verdad, este es tu sitio. Profesionalidad pura.',
      rating: 5,
      image: 'https://i.pravatar.cc/150?u=juan'
    }
  ];

  return (
    <section className="py-24 bg-zinc-900/50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <Quote className="absolute -top-10 -left-10 text-primary/5 w-64 h-64 -z-10" />
        
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-primary font-bold uppercase tracking-widest text-sm">Testimonios</h2>
          <h3 className="text-4xl md:text-5xl font-display font-black uppercase">LA VOZ DE <span className="text-primary">NUESTROS SOCIOS</span></h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-secondary p-8 rounded-3xl border border-white/5 relative">
              <div className="flex gap-1 mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} size={16} fill="#22d3ee" className="text-primary" />
                ))}
              </div>
              <p className="text-zinc-400 italic mb-8 leading-relaxed">"{review.text}"</p>
              <div className="flex items-center gap-4">
                <img src={review.image} alt={review.name} className="w-12 h-12 rounded-full border border-primary/30" />
                <div>
                  <p className="font-bold text-lg leading-none">{review.name}</p>
                  <p className="text-zinc-600 text-xs uppercase tracking-widest font-bold">Socio Activo</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
