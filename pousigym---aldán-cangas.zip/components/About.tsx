
import React from 'react';
import { Target, Heart, Users, Sparkles, ChevronRight } from 'lucide-react';

const About: React.FC = () => {
  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', view);
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string) => {
    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  return (
    <section id="sobre-nosotros" className="py-24 bg-zinc-950 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative order-2 lg:order-1">
            <div className="absolute -inset-10 bg-primary/10 rounded-full blur-[100px] animate-pulse"></div>
            <div className="relative space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <img 
                  src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1000&auto=format&fit=crop" 
                  alt="Pesas PousiGym" 
                  className="rounded-3xl shadow-2xl object-cover h-80 w-full hover:scale-105 transition-transform duration-500"
                />
                <img 
                  src="https://images.unsplash.com/photo-1593079831268-3381b0db4a77?q=80&w=1000&auto=format&fit=crop" 
                  alt="Entrenamiento" 
                  className="rounded-3xl shadow-2xl object-cover h-80 w-full mt-12 hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="absolute -bottom-10 -right-10 md:right-10 bg-primary text-secondary p-10 rounded-[2.5rem] shadow-2xl transform rotate-3 hidden md:block border-8 border-secondary">
                <p className="font-display text-5xl font-black italic leading-none">PGR</p>
                <p className="text-xs font-black uppercase tracking-[0.2em] mt-2">David Pousada</p>
              </div>
            </div>
          </div>

          <div className="space-y-10 order-1 lg:order-2">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-primary font-black uppercase tracking-[0.3em] text-xs">
                <Sparkles size={16} /> Nuestra Esencia
              </div>
              <h2 className="text-5xl md:text-6xl font-display font-black uppercase leading-tight tracking-tighter">
                MÁS QUE UN <br /><span className="text-primary">GIMNASIO</span>, UN ESTILO DE VIDA
              </h2>
              <p className="text-zinc-400 text-lg leading-relaxed font-medium">
                PousiGym nace de la pasión de David Pousada Rial por el entrenamiento bien hecho. En Aldán, hemos creado un santuario para el hierro y la salud, donde cada socio recibe una atención de élite.
              </p>
              <a 
                href={getUrl('entrenadores')}
                onClick={(e) => handleNavClick(e, 'entrenadores')}
                className="inline-flex items-center gap-2 bg-white/5 border border-white/10 hover:border-primary/50 text-white px-8 py-4 rounded-xl font-black uppercase tracking-widest transition-all group"
              >
                Conoce a nuestro equipo <ChevronRight size={18} className="text-primary group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            <div className="space-y-6 pt-4">
              {[
                { icon: <Target />, title: 'Rendimiento Real', desc: 'Métodos basados en evidencia para resultados que se ven y se sienten.' },
                { icon: <Users />, title: 'Cultura de Esfuerzo', desc: 'Un ambiente que te empuja a dar lo mejor de ti en cada sesión.' },
                { icon: <Heart />, title: 'Salud Integral', desc: 'No solo estética; buscamos tu bienestar físico y mental a largo plazo.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-6 group">
                  <div className="bg-white/5 p-4 rounded-2xl text-primary h-fit group-hover:bg-primary group-hover:text-secondary transition-all duration-300">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-black text-xl uppercase tracking-tight mb-1">{item.title}</h4>
                    <p className="text-zinc-500 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
