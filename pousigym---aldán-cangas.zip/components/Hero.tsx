
import React from 'react';
import { ChevronRight, Play, Trophy } from 'lucide-react';

const Hero: React.FC = () => {
  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', view);
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string, id: string) => {
    // Si el elemento existe en el DOM (estamos en vista completa), hacemos scroll suave
    const element = document.getElementById(id);
    if (element) {
      e.preventDefault();
      element.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  return (
    <section id="inicio" className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=2070&auto=format&fit=crop"
          alt="Muscular Athlete Background"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-secondary via-secondary/80 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-secondary via-transparent to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-32 pb-20">
        <div className="max-w-3xl space-y-10">
          <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-primary/15 border border-primary/30 text-primary text-[10px] md:text-xs font-black uppercase tracking-[0.2em]">
            <Trophy size={14} />
            El centro de referencia en el Morrazo
          </div>
          
          <h1 className="font-display text-6xl md:text-9xl font-black leading-[0.9] uppercase tracking-tighter">
            DOMINA TU <br />
            <span className="gradient-text">DESTINO</span>
          </h1>
          
          <p className="text-lg md:text-xl text-zinc-300 max-w-xl leading-relaxed font-medium">
            En PousiGym Aldán, David Pousada Rial te guía hacia tu mejor versión con ciencia, sudor y resultados garantizados. 
          </p>

          <div className="flex flex-col sm:flex-row gap-5 pt-4">
            <a 
              href={getUrl('tarifas')}
              onClick={(e) => handleNavClick(e, 'tarifas', 'tarifas')}
              className="flex items-center justify-center gap-3 bg-primary text-secondary px-10 py-5 rounded-2xl font-black uppercase tracking-widest transition-all hover:bg-white hover:shadow-2xl hover:shadow-primary/30 group text-center"
            >
              Empezar ahora <ChevronRight size={20} className="transition-transform group-hover:translate-x-1" />
            </a>
            <a 
              href={getUrl('sobre-nosotros')}
              onClick={(e) => handleNavClick(e, 'sobre-nosotros', 'sobre-nosotros')}
              className="flex items-center justify-center gap-3 backdrop-blur-md bg-white/5 border border-white/20 hover:bg-white/10 px-10 py-5 rounded-2xl font-black uppercase tracking-widest transition-all text-center"
            >
              <Play size={18} fill="currentColor" /> Tour Virtual
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-10 pt-16 border-t border-white/10 max-w-2xl">
            <div className="space-y-1">
              <div className="text-4xl font-display font-black text-white">500+</div>
              <div className="text-xs text-primary uppercase tracking-[0.2em] font-black">Atletas</div>
            </div>
            <div className="space-y-1">
              <div className="text-4xl font-display font-black text-white">15+</div>
              <div className="text-xs text-primary uppercase tracking-[0.2em] font-black">Años Exp.</div>
            </div>
            <div className="space-y-1 hidden md:block">
              <div className="text-4xl font-display font-black text-white">24/7</div>
              <div className="text-xs text-primary uppercase tracking-[0.2em] font-black">Motivación</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
