
import React, { useState } from 'react';
import { Sparkles, Loader2, ArrowRight } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const AISuggestion: React.FC = () => {
  const [tip, setTip] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const generateTip = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Dame un consejo corto y motivador (máximo 20 palabras) para alguien que está empezando a entrenar hoy en un gimnasio de alta gama. Usa un tono profesional y enérgico.",
        config: {
          systemInstruction: "Eres David Pousada, director de PousiGym. Eres motivador, técnico y directo. Tu marca usa colores cian y azul eléctrico."
        }
      });
      setTip(response.text || "La constancia es el único secreto. ¡Empieza hoy!");
    } catch (error) {
      setTip("Tu mayor competencia eres tú mismo ayer. ¡A por todas!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-24 bg-primary relative overflow-hidden group">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
      
      <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary text-primary rounded-full text-xs font-black uppercase tracking-[0.2em] mb-6 shadow-xl shadow-black/20">
          <Sparkles size={14} /> AI Training Assistant
        </div>
        
        <h2 className="text-secondary font-display text-4xl md:text-5xl font-black uppercase leading-tight mb-8">
          ¿NECESITAS UN EXTRA DE <span className="text-white">MOTIVACIÓN</span>?
        </h2>

        <div className="bg-secondary p-8 md:p-12 rounded-[40px] shadow-2xl relative border border-white/5">
          <div className="min-h-[60px] flex items-center justify-center">
            {loading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="animate-spin text-primary" size={32} />
                <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">Generando consejo...</p>
              </div>
            ) : (
              <p className="text-xl md:text-2xl font-bold italic text-zinc-200">
                {tip || "Haz clic abajo para recibir tu consejo del día de David Pousada."}
              </p>
            )}
          </div>
          
          <button 
            onClick={generateTip}
            disabled={loading}
            className="mt-8 bg-primary text-secondary px-8 py-3 rounded-full font-bold uppercase tracking-widest flex items-center gap-2 mx-auto hover:bg-white transition-all transform hover:scale-105 active:scale-95 disabled:opacity-50 shadow-lg shadow-primary/20"
          >
            Obtener consejo <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default AISuggestion;
