
import React from 'react';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contacto" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <div className="space-y-12">
            <div className="space-y-4">
              <h2 className="text-primary font-bold uppercase tracking-widest text-sm">Contacto</h2>
              <h3 className="text-4xl md:text-5xl font-display font-black uppercase">VAMOS A <span className="text-primary">EMPEZAR</span></h3>
              <p className="text-zinc-500 text-lg">Estamos en el corazón de Aldán, listos para ayudarte a alcanzar tus metas. Ven a visitarnos o escríbenos.</p>
            </div>

            <div className="space-y-8">
              <div className="flex gap-6 items-start">
                <div className="bg-primary/20 p-4 rounded-2xl text-primary">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-xl mb-1 uppercase tracking-tight">Ubicación</h4>
                  <p className="text-zinc-400">Rúa de Aldán, 36945 Cangas, Pontevedra, España</p>
                  <a href="https://maps.google.com" className="text-primary text-sm font-bold mt-2 inline-block hover:underline">Ver en Google Maps</a>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="bg-primary/20 p-4 rounded-2xl text-primary">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-xl mb-1 uppercase tracking-tight">Teléfono</h4>
                  <p className="text-zinc-400">+34 600 000 000</p>
                  <p className="text-zinc-600 text-sm">L-V: 07:00 - 22:00 | S: 09:00 - 14:00</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="bg-primary/20 p-4 rounded-2xl text-primary">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-xl mb-1 uppercase tracking-tight">Email</h4>
                  <p className="text-zinc-400">info@pousigym.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-secondary p-8 md:p-12 rounded-[40px] border border-white/5 relative">
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Nombre</label>
                  <input type="text" placeholder="Tu nombre" className="w-full bg-zinc-900 border border-white/10 rounded-xl px-5 py-4 focus:border-primary focus:outline-none transition-colors text-white" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Email</label>
                  <input type="email" placeholder="tu@email.com" className="w-full bg-zinc-900 border border-white/10 rounded-xl px-5 py-4 focus:border-primary focus:outline-none transition-colors text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Asunto</label>
                <select className="w-full bg-zinc-900 border border-white/10 rounded-xl px-5 py-4 focus:border-primary focus:outline-none transition-colors text-white">
                  <option>Información General</option>
                  <option>Prueba Gratuita</option>
                  <option>Entrenamiento Personal</option>
                  <option>Bajas/Consultas</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Mensaje</label>
                <textarea rows={4} placeholder="¿En qué podemos ayudarte?" className="w-full bg-zinc-900 border border-white/10 rounded-xl px-5 py-4 focus:border-primary focus:outline-none transition-colors text-white resize-none"></textarea>
              </div>
              <button className="w-full bg-primary text-secondary py-5 rounded-xl font-black uppercase tracking-[0.2em] flex items-center justify-center gap-2 hover:bg-accent transition-all">
                Enviar mensaje <Send size={18} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
