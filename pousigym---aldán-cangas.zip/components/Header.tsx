
import React, { useState, useEffect } from 'react';
import { Menu, X, Dumbbell } from 'lucide-react';

interface HeaderProps {
  currentView?: string;
}

const Header: React.FC<HeaderProps> = ({ currentView }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Inicio', view: 'inicio', id: 'inicio' },
    { name: 'Sobre Nosotros', view: 'sobre-nosotros', id: 'sobre-nosotros' },
    { name: 'Servicios', view: 'servicios', id: 'servicios' },
    { name: 'Horarios', view: 'horarios', id: 'horarios' },
    { name: 'Entrenadores', view: 'entrenadores', id: 'entrenadores' },
    { name: 'Tarifas', view: 'tarifas', id: 'tarifas' },
    { name: 'Contacto', view: 'contacto', id: 'contacto' },
  ];

  const getUrl = (view: string) => {
    try {
      const url = new URL(window.location.href);
      if (view === 'inicio' || view === 'full') {
        url.searchParams.delete('view');
      } else {
        url.searchParams.set('view', view);
      }
      return url.toString();
    } catch (e) {
      return `?view=${view}`;
    }
  };

  const handleNavClick = (e: React.MouseEvent, view: string, id: string) => {
    // Si estamos en la vista completa, intentamos hacer scroll suave
    if (currentView === 'full' || !currentView) {
      const element = document.getElementById(id);
      if (element) {
        e.preventDefault();
        element.scrollIntoView({ behavior: 'smooth' });
        setIsOpen(false);
        return;
      }
    }

    // Si no estamos en la vista completa o el elemento no existe, navegamos normalmente
    if (!e.ctrlKey && !e.metaKey) {
      e.preventDefault();
      const url = getUrl(view);
      window.history.pushState({}, '', url);
      window.dispatchEvent(new PopStateEvent('popstate'));
      setIsOpen(false);
    }
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-secondary/95 backdrop-blur-md py-3 shadow-2xl border-b border-white/5' 
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <a 
            href={getUrl('inicio')}
            className="flex items-center gap-3 group cursor-pointer"
            onClick={(e) => handleNavClick(e, 'inicio', 'inicio')}
          >
            <div className="bg-primary p-2 rounded-lg transition-transform group-hover:rotate-12">
              <Dumbbell className="text-secondary w-6 h-6" />
            </div>
            <span className="font-display text-2xl md:text-3xl font-black tracking-tighter italic uppercase">
              POUSI<span className="text-primary">GYM</span>
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={getUrl(link.view)}
                onClick={(e) => handleNavClick(e, link.view, link.id)}
                className={`text-xs font-bold uppercase tracking-widest transition-colors ${
                  currentView === link.view 
                    ? 'text-primary' 
                    : 'text-zinc-300 hover:text-primary'
                }`}
              >
                {link.name}
              </a>
            ))}
            <a
              href={getUrl('tarifas')}
              onClick={(e) => handleNavClick(e, 'tarifas', 'tarifas')}
              className="bg-primary text-secondary px-7 py-2.5 rounded-full font-black uppercase tracking-tighter text-sm hover:bg-white hover:scale-105 transition-all shadow-lg shadow-primary/20"
            >
              Apúntate ahora
            </a>
          </nav>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white p-2 focus:outline-none bg-white/5 rounded-lg"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <div 
        className={`lg:hidden absolute w-full bg-secondary border-b border-white/10 transition-all duration-300 ease-in-out overflow-hidden ${
          isOpen ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-4 pt-2 pb-6 space-y-1">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={getUrl(link.view)}
              onClick={(e) => handleNavClick(e, link.view, link.id)}
              className={`block px-4 py-4 text-sm font-bold uppercase tracking-widest border-b border-white/5 last:border-0 transition-colors ${
                currentView === link.view ? 'text-primary' : 'hover:text-primary'
              }`}
            >
              {link.name}
            </a>
          ))}
          <div className="pt-4">
            <a
              href={getUrl('tarifas')}
              onClick={(e) => handleNavClick(e, 'tarifas', 'tarifas')}
              className="block w-full bg-primary text-secondary py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-primary/10 text-center"
            >
              Apúntate ahora
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
